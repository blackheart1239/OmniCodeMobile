package com.omnicodemobile.app

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONObject
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val worker = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = false
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(OfflineBridge(), "OmniBridge")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class OfflineBridge {
        @JavascriptInterface
        fun execute(language: String, source: String) {
            worker.execute {
                val result = try {
                    when (language.lowercase()) {
                        "python" -> Python.getInstance()
                            .getModule("omni_runner")
                            .callAttr("run_code", source)
                            .toString()
                        else -> "Offline runtime not bundled for ${language}.\n\nCurrently supported offline: JavaScript and Python. C, C++, Java, C# and the other listed languages need their own on-device compiler/runtime, which is not included in this build."
                    }
                } catch (e: Exception) {
                    "Offline execution failed: ${e.message ?: e.javaClass.simpleName}"
                }
                val safe = JSONObject.quote(result)
                mainHandler.post { webView.evaluateJavascript("window.showOutput($safe)", null) }
            }
        }

        @JavascriptInterface
        fun saveText(filename: String, content: String) {
            val message = JSONObject.quote("File export is not implemented yet. Copy your code from the editor.")
            mainHandler.post { webView.evaluateJavascript("window.showOutput($message)", null) }
        }
    }

    override fun onDestroy() {
        worker.shutdownNow()
        webView.destroy()
        super.onDestroy()
    }
}
