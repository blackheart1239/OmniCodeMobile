import contextlib
import io
import traceback

def run_code(source):
    stdout = io.StringIO()
    stderr = io.StringIO()
    namespace = {"__name__": "__main__"}
    try:
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            exec(compile(source, "<omnicode>", "exec"), namespace, namespace)
    except BaseException:
        traceback.print_exc(file=stderr)
    parts = []
    out = stdout.getvalue()
    err = stderr.getvalue()
    if out:
        parts.append(out.rstrip("\\n"))
    if err:
        parts.append("[error / stderr]\\n" + err.rstrip("\\n"))
    return "\\n".join(parts) if parts else "Program finished with no output."
