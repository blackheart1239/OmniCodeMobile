#!/usr/bin/env python3
"""Build an experimental ARM64 Termux/Android Clang bundle for OmniCode.
Run only on Ubuntu GitHub Actions. Output: omnicode-clang-arm64.zip.
"""
import lzma, urllib.request, subprocess, tempfile, pathlib, re, shutil, os, sys
BASE='https://packages.termux.dev/apt/termux-main'
INDEX=BASE+'/dists/stable/main/binary-aarch64/Packages.xz'
ROOT=pathlib.Path('toolchain-build').resolve(); debdir=ROOT/'debs'; prefix=ROOT/'prefix'
shutil.rmtree(ROOT,ignore_errors=True); debdir.mkdir(parents=True); prefix.mkdir(parents=True)
print('Downloading Termux ARM64 package index...')
with urllib.request.urlopen(INDEX, timeout=90) as r: raw=lzma.decompress(r.read()).decode('utf-8','replace')
packages={}
for para in re.split(r'\n\n+',raw):
    fields={}
    for line in para.splitlines():
        if line.startswith(' ') and fields: fields[list(fields)[-1]] += ' '+line.strip()
        elif ': ' in line:
            k,v=line.split(': ',1); fields[k]=v
    if fields.get('Package') and fields.get('Filename'): packages[fields['Package']]=fields
roots=['clang','libllvm','lld','ndk-sysroot','libcompiler-rt','libc++','libxml2','libffi','ncurses','zlib','zstd']
needed=[]; seen=set()
def deps(field):
    out=[]
    for group in field.split(','):
        alternatives=group.split('|')
        for alt in alternatives:
            name=re.match(r'\s*([a-zA-Z0-9+.-]+)',alt)
            if name and name.group(1) in packages:
                out.append(name.group(1)); break
    return out
def visit(name):
    if name in seen: return
    if name not in packages: raise RuntimeError('Missing package in repository index: '+name)
    seen.add(name); p=packages[name]
    for d in deps(p.get('Depends','')): visit(d)
    needed.append(name)
for name in roots: visit(name)
print('Resolved packages:', ', '.join(needed))
for name in needed:
    p=packages[name]; url=BASE+'/'+p['Filename']
    dest=debdir/pathlib.Path(p['Filename']).name
    print('Downloading',name,p.get('Version',''))
    with urllib.request.urlopen(url,timeout=120) as r: dest.write_bytes(r.read())
    unpack=ROOT/'unpack'; shutil.rmtree(unpack,ignore_errors=True); unpack.mkdir()
    subprocess.run(['dpkg-deb','-x',str(dest),str(unpack)],check=True)
    termux_prefix=unpack/'data/data/com.termux/files/usr'
    payload=termux_prefix if termux_prefix.exists() else unpack/'usr'
    if not payload.exists(): raise RuntimeError('Could not locate Termux prefix in '+name)
    subprocess.run(['cp','-a',str(payload)+ '/.',str(prefix) + '/'],check=True)
# Dereference symlinks: Android's Java ZIP extractor cannot recreate Unix symlinks.
stage=ROOT/'stage'; shutil.copytree(prefix,stage,symlinks=False)
out=pathlib.Path('omnicode-clang-arm64.zip')
subprocess.run(['zip','-qr',str(out.resolve()),'.'],cwd=stage,check=True)
print('Created',out.resolve(),'bytes=',out.stat().st_size)
