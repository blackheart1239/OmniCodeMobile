plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}

android {
    namespace = "com.omnicodemobile.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.omnicodemobile.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.2.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    sourceSets {
        getByName("main") {
            python.srcDir("src/main/python")
        }
    }

    // Chaquopy bundles a CPython runtime in the APK. The Android ABI list
    // keeps the package compatible with common modern Android phones.
    ndk {
        abiFilters += listOf("arm64-v8a", "armeabi-v7a", "x86_64")
    }
}

chaquopy {
    defaultConfig {
        version = "3.12"
    }
}
