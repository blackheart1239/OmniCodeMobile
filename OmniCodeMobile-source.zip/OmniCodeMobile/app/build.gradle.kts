plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}

android {
    namespace = "com.omnicodemobile.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.omnicodemobile.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 6
        versionName = "0.5.0-alpha.2"

        // Include common Android ABIs for the embedded Python runtime.
        ndk {
            abiFilters.addAll(listOf("arm64-v8a", "x86_64"))
        }
    }

    signingConfigs {
        create("release") {
            val keystorePath = System.getenv("OMNICODE_KEYSTORE_PATH")
            if (!keystorePath.isNullOrBlank()) {
                storeFile = file(keystorePath)
                storePassword = System.getenv("OMNICODE_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("OMNICODE_KEY_ALIAS")
                keyPassword = System.getenv("OMNICODE_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        getByName("release") {
            val keystorePath = System.getenv("OMNICODE_KEYSTORE_PATH")
            if (!keystorePath.isNullOrBlank()) signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
}

chaquopy {
    defaultConfig {
        version = "3.12"
    }
}
