package com.omnicodemobile.app

import android.content.Context
import java.io.File

/** Offline C compiler (embedded TinyCC). C++ is not supported by TinyCC. */
object NativeC {
    private var loaded = false
    private external fun run(source: String, includeDir: String, timeoutSec: Int): String

    fun available(): Boolean = try { ensureLoaded(); true } catch (_: Throwable) { false }

    private fun ensureLoaded() {
        if (!loaded) { System.loadLibrary("omnicc"); loaded = true }
    }

    private fun prepareHeaders(ctx: Context): File {
        val dir = File(ctx.filesDir, "cinclude")
        if (!dir.exists()) dir.mkdirs()
        ctx.assets.list("cinclude")?.forEach { name ->
            val out = File(dir, name)
            if (!out.exists()) ctx.assets.open("cinclude/$name").use { i -> out.outputStream().use { i.copyTo(it) } }
        }
        return dir
    }

    fun compileAndRun(ctx: Context, source: String): String {
        ensureLoaded()
        val out = run(source, prepareHeaders(ctx).absolutePath, 10)
        return (out.ifBlank { "Program finished with no output." }) + "\n\n[Compiled & run offline with TinyCC]"
    }
}
