package com.omnicodemobile.app

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.os.Build
import android.provider.Settings
import android.net.Uri
import android.content.pm.PackageManager
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val worker = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var pendingExportText: String = ""
    private var pendingExportName: String = "main.txt"
    private val githubRepo = "blackheart1239/OmniCodeMobile"
    private val currentVersion = "0.5.0-alpha.2"
    private val toolchainAssetName = "omnicode-clang-arm64.zip"
    private val toolchainDir: File by lazy { File(filesDir, "omni-toolchain") }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(OfflineBridge(), "OmniBridge")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun showOnUi(message: String) {
        val safe = JSONObject.quote(message)
        mainHandler.post { if (::webView.isInitialized) webView.evaluateJavascript("window.showOutput($safe)", null) }
    }

    inner class OfflineBridge {
        @JavascriptInterface
        fun execute(language: String, source: String) {
            worker.execute {
                val result = try {
                    when (language.lowercase()) {
                        "python" -> Python.getInstance().getModule("omni_runner").callAttr("run_code", source).toString()
                        "c" -> runNativeCompiler("c", source)
                        "cpp" -> runNativeCompiler("cpp", source)
                        else -> "Runtime not included for $language."
                    }
                } catch (e: Exception) {
                    "Execution failed: ${e.message ?: e.javaClass.simpleName}"
                }
                showOnUi(result)
            }
        }

        @JavascriptInterface
        fun installOfflineCompiler() {
            worker.execute {
                val result = try { installToolchainFromRelease() } catch (e: Exception) {
                    "Compiler installation failed: ${e.message ?: e.javaClass.simpleName}"
                }
                showOnUi(result)
            }
        }

        fun checkForUpdates() {
            worker.execute {
                val result = try { checkLatestRelease() } catch (e: Exception) {
                    "Update check failed: ${e.message ?: e.javaClass.simpleName}"
                }
                val safe = JSONObject.quote(result)
                mainHandler.post { if (::webView.isInitialized) webView.evaluateJavascript("window.updateStatus($safe)", null) }
            }
        }

        @JavascriptInterface
        fun importText() {
            runOnUiThread { val intent = android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(android.content.Intent.CATEGORY_OPENABLE); type = "*/*" }; startActivityForResult(intent, 4101) }
        }

        @JavascriptInterface
        fun saveText(filename: String, content: String) {
            pendingExportName = filename.ifBlank { "main.txt" }
            pendingExportText = content
            runOnUiThread { val intent = android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(android.content.Intent.CATEGORY_OPENABLE); type = "text/plain"; putExtra(android.content.Intent.EXTRA_TITLE, pendingExportName) }; startActivityForResult(intent, 4102) }
        }
    }

    private fun runNativeCompiler(language: String, source: String): String {
        val clang = File(toolchainDir, "bin/clang")
        val clangxx = File(toolchainDir, "bin/clang++")
        if (!clang.isFile || !clangxx.isFile) {
            return "Offline C/C++ toolchain is not installed. Connect to the internet, attach $toolchainAssetName to a public GitHub Release, then tap Install offline compiler."
        }
        val work = File(cacheDir, "native-work").apply { mkdirs() }
        val ext = if (language == "c") "c" else "cpp"
        val src = File(work, "main.$ext")
        val exe = File(work, "main")
        src.writeText(source)
        exe.delete()
        val resourceDir = File(toolchainDir, "lib/clang")
        val versionDir = resourceDir.listFiles()?.filter { it.isDirectory }?.maxByOrNull { it.name } 
        val compiler = if (language == "c") clang else clangxx
        val command = mutableListOf(compiler.absolutePath,
            "--target=aarch64-linux-android26",
            "--sysroot=${toolchainDir.absolutePath}")
        if (versionDir != null) command.add("-resource-dir=${versionDir.absolutePath}")
        command.addAll(listOf("-I${toolchainDir.absolutePath}/include", "-isystem", "${toolchainDir.absolutePath}/include/c++/v1", "-L${toolchainDir.absolutePath}/lib", "-Wl,-rpath,${toolchainDir.absolutePath}/lib", "-O0", src.absolutePath, "-o", exe.absolutePath))
        if (language == "cpp") command.addAll(listOf("-std=c++17", "-stdlib=libc++"))
        val envLib = File(toolchainDir, "lib").absolutePath
        val compile = runProcess(command, work, envLib)
        if (compile.first != 0) return "[compile failed]\n${compile.second.ifBlank { "Compiler exited with code ${compile.first}." }}"
        if (!exe.exists()) return "Compilation reported success but no executable was created.\n${compile.second}"
        exe.setExecutable(true, true)
        val run = runProcess(listOf(exe.absolutePath), work, envLib)
        return buildString {
            if (compile.second.isNotBlank()) append("[compiler]\n${compile.second}\n\n")
            if (run.second.isBlank()) append(if (run.first == 0) "Program finished with no output." else "Program exited with code ${run.first}.")
            else append(run.second)
            if (run.first != 0) append("\n\n[exit code ${run.first}]")
            append("\n\n[Local compiler: offline after toolchain installation]")
        }
    }

    private fun runProcess(command: List<String>, directory: File, libraryPath: String): Pair<Int, String> {
        val process = ProcessBuilder(command).directory(directory).redirectErrorStream(true).apply {
            environment()["PREFIX"] = toolchainDir.absolutePath
            environment()["TERMUX_PREFIX"] = toolchainDir.absolutePath
            environment()["LD_LIBRARY_PATH"] = libraryPath + ":" + (environment()["LD_LIBRARY_PATH"] ?: "")
            environment()["TMPDIR"] = cacheDir.absolutePath
        }.start()
        val output = process.inputStream.bufferedReader().use { it.readText() }
        val code = process.waitFor()
        return Pair(code, output)
    }

    private fun installToolchainFromRelease(): String {
        if (toolchainDir.resolve("bin/clang").isFile && toolchainDir.resolve("bin/clang++").isFile) {
            return "Offline C/C++ compiler is already installed. You can compile without internet."
        }
        val api = (URL("https://api.github.com/repos/$githubRepo/releases?per_page=20").openConnection() as HttpURLConnection)
        val releasesText: String
        try {
            api.connectTimeout = 12000; api.readTimeout = 15000
            api.setRequestProperty("Accept", "application/vnd.github+json")
            api.setRequestProperty("User-Agent", "OmniCode-Mobile-Toolchain")
            if (api.responseCode !in 200..299) return "Could not find toolchain release (HTTP ${api.responseCode})."
            releasesText = api.inputStream.bufferedReader().use { it.readText() }
        } finally { api.disconnect() }
        var downloadUrl = ""
        val releases = org.json.JSONArray(releasesText)
        for (i in 0 until releases.length()) {
            val assets = releases.optJSONObject(i)?.optJSONArray("assets") ?: continue
            for (j in 0 until assets.length()) {
                val asset = assets.optJSONObject(j) ?: continue
                if (asset.optString("name") == toolchainAssetName) {
                    downloadUrl = asset.optString("browser_download_url")
                    break
                }
            }
            if (downloadUrl.isNotBlank()) break
        }
        if (!downloadUrl.startsWith("https://")) return "Toolchain asset '$toolchainAssetName' was not found in public GitHub Releases. Build the toolchain artifact in Actions and attach it to a release first."
        val archive = File(cacheDir, toolchainAssetName)
        val connection = URL(downloadUrl).openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = 15000; connection.readTimeout = 120000
            connection.setRequestProperty("User-Agent", "OmniCode-Mobile-Toolchain")
            if (connection.responseCode !in 200..299) return "Toolchain download failed (HTTP ${connection.responseCode})."
            connection.inputStream.use { input -> archive.outputStream().use { output -> input.copyTo(output) } }
        } finally { connection.disconnect() }
        if (archive.length() < 1_000_000) { archive.delete(); return "Downloaded toolchain archive is too small; refusing to install it." }
        val temp = File(filesDir, "omni-toolchain-installing")
        deleteRecursively(temp); temp.mkdirs()
        extractToolchainZip(archive, temp)
        if (!File(temp, "bin/clang").isFile || !File(temp, "bin/clang++").isFile) {
            deleteRecursively(temp); archive.delete()
            return "Toolchain archive is missing bin/clang or bin/clang++. No compiler was installed."
        }
        deleteRecursively(toolchainDir)
        if (!temp.renameTo(toolchainDir)) { deleteRecursively(temp); return "Could not activate toolchain in app storage." }
        archive.delete()
        return "Offline C/C++ toolchain installed. Test with a simple program; this alpha integration has not been device-verified."
    }

    private fun extractToolchainZip(archive: File, destination: File) {
        java.util.zip.ZipInputStream(archive.inputStream().buffered()).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                val outFile = File(destination, entry.name).canonicalFile
                require(outFile.toPath().startsWith(destination.canonicalFile.toPath())) { "Unsafe path in toolchain archive" }
                if (entry.isDirectory) outFile.mkdirs() else {
                    outFile.parentFile?.mkdirs()
                    outFile.outputStream().use { output -> zip.copyTo(output) }
                    val rel = destination.toPath().relativize(outFile.toPath()).toString().replace('\\', '/')
                    if (rel.startsWith("bin/") || rel.startsWith("libexec/")) outFile.setExecutable(true, true)
                }
                zip.closeEntry()
            }
        }
    }

    private fun deleteRecursively(file: File) {
        if (file.isDirectory) file.listFiles()?.forEach { deleteRecursively(it) }
        file.delete()
    }

    private fun checkLatestRelease(): String {
        val connection = (URL("https://api.github.com/repos/$githubRepo/releases?per_page=20").openConnection() as HttpURLConnection)
        val releasesText: String
        try {
            connection.connectTimeout = 12000
            connection.readTimeout = 15000
            connection.setRequestProperty("Accept", "application/vnd.github+json")
            connection.setRequestProperty("User-Agent", "OmniCode-Mobile-Updater")
            val status = connection.responseCode
            if (status !in 200..299) return "GitHub update check failed (HTTP $status)."
            releasesText = connection.inputStream.bufferedReader().use { it.readText() }
        } finally { connection.disconnect() }

        val releases = org.json.JSONArray(releasesText)
        val currentCode = versionRank(currentVersion)
        for (i in 0 until releases.length()) {
            val release = releases.optJSONObject(i) ?: continue
            if (release.optBoolean("draft", false)) continue
            val tag = release.optString("tag_name", "")
            if (versionRank(tag) <= currentCode) continue
            val assets = release.optJSONArray("assets") ?: continue
            for (j in 0 until assets.length()) {
                val asset = assets.optJSONObject(j) ?: continue
                val name = asset.optString("name", "")
                val url = asset.optString("browser_download_url", "")
                if (name.endsWith(".apk", true) && url.startsWith("https://")) {
                    mainHandler.post { promptDownloadUpdate(tag, url, name) }
                    return "Update found: $tag. Review the prompt to download it."
                }
            }
        }
        return "You're using $currentVersion. No newer GitHub release with an APK was found."
    }

    private fun versionRank(tag: String): Long {
        val match = Regex("[vV]?(\\d+)\\.(\\d+)\\.(\\d+)(?:-([A-Za-z]+)(?:[.-]?(\\d+))?)?").find(tag) ?: return 0L
        val major = match.groupValues[1].toLongOrNull() ?: 0L
        val minor = match.groupValues[2].toLongOrNull() ?: 0L
        val patch = match.groupValues[3].toLongOrNull() ?: 0L
        val stage = match.groupValues[4].lowercase()
        val stageNumber = match.groupValues[5].toLongOrNull() ?: 0L
        val stageRank = when (stage) {
            "alpha" -> 10L + stageNumber.coerceAtMost(99L)
            "beta" -> 200L + stageNumber.coerceAtMost(99L)
            "rc" -> 400L + stageNumber.coerceAtMost(99L)
            "" -> 999L
            else -> 5L
        }
        return major * 1_000_000_000L + minor * 1_000_000L + patch * 1_000L + stageRank
    }

    private fun promptDownloadUpdate(tag: String, url: String, name: String) {
        android.app.AlertDialog.Builder(this)
            .setTitle("OmniCode update available")
            .setMessage("Version $tag is available. Download and install it? Android will ask you to confirm installation.")
            .setNegativeButton("Later", null)
            .setPositiveButton("Download") { _, _ -> downloadAndInstall(url, name) }
            .show()
    }

    private fun downloadAndInstall(url: String, name: String) {
        worker.execute {
            var connection: HttpURLConnection? = null
            try {
                connection = (URL(url).openConnection() as HttpURLConnection)
                connection.connectTimeout = 15000
                connection.readTimeout = 45000
                connection.setRequestProperty("User-Agent", "OmniCode-Mobile-Updater")
                if (connection.responseCode !in 200..299) throw IllegalStateException("Download failed (HTTP ${connection.responseCode})")
                val dir = File(cacheDir, "updates")
                if (!dir.exists() && !dir.mkdirs()) throw IllegalStateException("Cannot create update folder")
                val apk = File(dir, "omnicode-update.apk")
                connection.inputStream.use { input -> apk.outputStream().use { output -> input.copyTo(output) } }
                if (apk.length() < 100_000) throw IllegalStateException("Downloaded file is too small to be a valid APK")
                mainHandler.post {
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !packageManager.canRequestPackageInstalls()) {
                            val settingsIntent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
                            startActivity(settingsIntent)
                            android.widget.Toast.makeText(this, "Allow installs from this source, then tap Check updates again.", android.widget.Toast.LENGTH_LONG).show()
                            return@post
                        }
                        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", apk)
                        val install = Intent(Intent.ACTION_VIEW).apply {
                            setDataAndType(uri, "application/vnd.android.package-archive")
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        startActivity(install)
                    } catch (e: Exception) {
                        showOnUi("Could not start installer: ${e.message ?: e.javaClass.simpleName}")
                    }
                }
            } catch (e: Exception) {
                showOnUi("Update download failed: ${e.message ?: e.javaClass.simpleName}")
            } finally { connection?.disconnect() }
        }
    }

    private fun runWandbox(compiler: String, source: String): String {
        val payload = JSONObject().apply {
            put("compiler", compiler)
            put("code", source)
            put("save", false)
            put("stdin", "")
        }.toString()
        val connection = (URL("https://wandbox.org/api/compile.json").openConnection() as HttpURLConnection)
        try {
            connection.requestMethod = "POST"
            connection.connectTimeout = 15000
            connection.readTimeout = 30000
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            connection.setRequestProperty("Accept", "application/json")
            connection.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (status !in 200..299) return "Online compiler request failed (HTTP $status).\n$body"
            val json = JSONObject(body)
            val parts = mutableListOf<String>()
            val compileMessage = json.optString("compiler_message", "").trim()
            val programOutput = json.optString("program_output", "").trimEnd()
            val programMessage = json.optString("program_message", "").trim()
            if (compileMessage.isNotBlank()) parts.add("[compiler]\n$compileMessage")
            if (programOutput.isNotBlank()) parts.add(programOutput)
            if (programMessage.isNotBlank() && programMessage != programOutput) parts.add("[program]\n$programMessage")
            if (parts.isEmpty()) parts.add(if (json.optString("status") == "0") "Program finished with no output." else "Compiler returned no output.\n$body")
            return parts.joinToString("\n\n") + "\n\n[Compiled online by Wandbox; internet required.]"
        } finally {
            connection.disconnect()
        }
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        when (requestCode) {
            4101 -> try {
                val content = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                val name = uri.lastPathSegment?.substringAfterLast('/') ?: "imported.txt"
                val safeContent = JSONObject.quote(content)
                val safeName = JSONObject.quote(name)
                webView.evaluateJavascript("window.loadImportedCode($safeContent, $safeName)", null)
            } catch (e: Exception) {
                showOnUi("Import failed: ${e.message ?: e.javaClass.simpleName}")
            }
            4102 -> try {
                contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(pendingExportText) }
                showOnUi("Saved ${pendingExportName} successfully.")
            } catch (e: Exception) {
                showOnUi("Export failed: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    override fun onDestroy() {
        worker.shutdownNow()
        webView.destroy()
        super.onDestroy()
    }
}
