package com.omnicodemobile.app

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val worker = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var pendingExportText: String = ""
    private var pendingExportName: String = "main.txt"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(OfflineBridge(), "OmniBridge")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun showOnUi(message: String) {
        val safe = JSONObject.quote(message)
        mainHandler.post { if (::webView.isInitialized) webView.evaluateJavascript("window.showOutput($safe)", null) }
    }

    inner class OfflineBridge {
        @JavascriptInterface
        fun execute(language: String, source: String) {
            worker.execute {
                val result = try {
                    when (language.lowercase()) {
                        "python" -> Python.getInstance().getModule("omni_runner").callAttr("run_code", source).toString()
                        "c" -> runWandbox("gcc-head-c", source)
                        "cpp" -> runWandbox("gcc-head", source)
                        else -> "Runtime not included for $language."
                    }
                } catch (e: Exception) {
                    "Execution failed: ${e.message ?: e.javaClass.simpleName}"
                }
                showOnUi(result)
            }
        }

        @JavascriptInterface
        fun importText() {
            runOnUiThread { val intent = android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(android.content.Intent.CATEGORY_OPENABLE); type = "*/*" }; startActivityForResult(intent, 4101) }
        }

        @JavascriptInterface
        fun saveText(filename: String, content: String) {
            pendingExportName = filename.ifBlank { "main.txt" }
            pendingExportText = content
            runOnUiThread { val intent = android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(android.content.Intent.CATEGORY_OPENABLE); type = "text/plain"; putExtra(android.content.Intent.EXTRA_TITLE, pendingExportName) }; startActivityForResult(intent, 4102) }
        }
    }

    private fun runWandbox(compiler: String, source: String): String {
        val payload = JSONObject().apply {
            put("compiler", compiler)
            put("code", source)
            put("save", false)
            put("stdin", "")
        }.toString()
        val connection = (URL("https://wandbox.org/api/compile.json").openConnection() as HttpURLConnection)
        try {
            connection.requestMethod = "POST"
            connection.connectTimeout = 15000
            connection.readTimeout = 30000
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            connection.setRequestProperty("Accept", "application/json")
            connection.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (status !in 200..299) return "Online compiler request failed (HTTP $status).\n$body"
            val json = JSONObject(body)
            val parts = mutableListOf<String>()
            val compileMessage = json.optString("compiler_message", "").trim()
            val programOutput = json.optString("program_output", "").trimEnd()
            val programMessage = json.optString("program_message", "").trim()
            if (compileMessage.isNotBlank()) parts.add("[compiler]\n$compileMessage")
            if (programOutput.isNotBlank()) parts.add(programOutput)
            if (programMessage.isNotBlank() && programMessage != programOutput) parts.add("[program]\n$programMessage")
            if (parts.isEmpty()) parts.add(if (json.optString("status") == "0") "Program finished with no output." else "Compiler returned no output.\n$body")
            return parts.joinToString("\n\n") + "\n\n[Compiled online by Wandbox; internet required.]"
        } finally {
            connection.disconnect()
        }
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        when (requestCode) {
            4101 -> try {
                val content = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                val name = uri.lastPathSegment?.substringAfterLast('/') ?: "imported.txt"
                val safeContent = JSONObject.quote(content)
                val safeName = JSONObject.quote(name)
                webView.evaluateJavascript("window.loadImportedCode($safeContent, $safeName)", null)
            } catch (e: Exception) {
                showOnUi("Import failed: ${e.message ?: e.javaClass.simpleName}")
            }
            4102 -> try {
                contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(pendingExportText) }
                showOnUi("Saved ${pendingExportName} successfully.")
            } catch (e: Exception) {
                showOnUi("Export failed: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    override fun onDestroy() {
        worker.shutdownNow()
        webView.destroy()
        super.onDestroy()
    }
}
