// OmniCode offline C runner: compiles C with embedded TinyCC and runs main() in a forked child
// so crashes / infinite loops in user code cannot kill the app. Output is captured via a pipe.
#include <jni.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <poll.h>
#include <errno.h>
#include "libtcc.h"

#define MAX_OUT (256 * 1024)

static char g_err[16384];
static void on_tcc_error(void *opaque, const char *msg) {
    size_t n = strlen(g_err);
    snprintf(g_err + n, sizeof(g_err) - n, "%s\n", msg);
}

JNIEXPORT jstring JNICALL
Java_com_omnicodemobile_app_NativeC_run(JNIEnv *env, jclass cls, jstring jsrc, jstring jinc, jint timeoutSec) {
    const char *src = (*env)->GetStringUTFChars(env, jsrc, NULL);
    const char *inc = (*env)->GetStringUTFChars(env, jinc, NULL);
    char *result = calloc(1, MAX_OUT + 4096);
    g_err[0] = 0;

    int pfd[2];
    if (pipe(pfd) != 0) { strcpy(result, "pipe() failed"); goto done; }
    fflush(NULL);
    pid_t pid = fork();
    if (pid < 0) { strcpy(result, "fork() failed"); goto done; }

    if (pid == 0) {
        close(pfd[0]);
        dup2(pfd[1], 1); dup2(pfd[1], 2);
        setvbuf(stdout, NULL, _IONBF, 0);
        alarm((unsigned)timeoutSec);
        TCCState *s = tcc_new();
        tcc_set_error_func(s, NULL, on_tcc_error);
        tcc_set_options(s, "-nostdlib -nostdinc");
        tcc_add_sysinclude_path(s, inc);
        tcc_add_include_path(s, inc);
        tcc_set_output_type(s, TCC_OUTPUT_MEMORY);
        if (tcc_compile_string(s, src) == -1) {
            dprintf(1, "[compiler]\n%s", g_err);
            _exit(1);
        }
        if (g_err[0]) dprintf(1, "[compiler warnings]\n%s\n", g_err);
        int rc = tcc_run(s, 0, NULL);
        fflush(NULL);
        _exit(rc & 0xff);
    }

    close(pfd[1]);
    size_t len = 0;
    for (;;) {
        struct pollfd p = { pfd[0], POLLIN, 0 };
        int r = poll(&p, 1, (timeoutSec + 2) * 1000);
        if (r <= 0) { kill(pid, SIGKILL); break; }
        ssize_t n = read(pfd[0], result + len, MAX_OUT - len);
        if (n <= 0) break;
        len += (size_t)n;
        if (len >= MAX_OUT) { kill(pid, SIGKILL); strcat(result, "\n[output truncated]"); break; }
    }
    close(pfd[0]);
    int st = 0; waitpid(pid, &st, 0);
    if (WIFSIGNALED(st)) {
        int sg = WTERMSIG(st);
        char tail[160];
        snprintf(tail, sizeof(tail), "\n[program stopped: %s]", sg == SIGALRM ? "time limit reached" : strsignal(sg));
        strcat(result, tail);
    } else if (WIFEXITED(st) && WEXITSTATUS(st) != 0 && len > 0 && strncmp(result, "[compiler]", 10) != 0) {
        char tail[64]; snprintf(tail, sizeof(tail), "\n[exit code %d]", WEXITSTATUS(st)); strcat(result, tail);
    }
done:
    (*env)->ReleaseStringUTFChars(env, jsrc, src);
    (*env)->ReleaseStringUTFChars(env, jinc, inc);
    jstring out = (*env)->NewStringUTF(env, result);
    free(result);
    return out;
}
