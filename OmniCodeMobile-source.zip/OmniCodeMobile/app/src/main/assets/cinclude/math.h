#ifndef _MATH_H
#define _MATH_H
#define M_PI 3.14159265358979323846
#define M_E 2.7182818284590452354
double sin(double),cos(double),tan(double),asin(double),acos(double),atan(double),atan2(double,double);
double sqrt(double),cbrt(double),pow(double,double),exp(double),log(double),log10(double),log2(double);
double fabs(double),floor(double),ceil(double),round(double),fmod(double,double),hypot(double,double);
#endif
