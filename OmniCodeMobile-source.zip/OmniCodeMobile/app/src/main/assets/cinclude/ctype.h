#ifndef _CTYPE_H
#define _CTYPE_H
int isalpha(int),isdigit(int),isalnum(int),isspace(int),isupper(int),islower(int),ispunct(int),isxdigit(int),toupper(int),tolower(int);
#endif
