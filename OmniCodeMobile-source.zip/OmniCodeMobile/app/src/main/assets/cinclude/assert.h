#ifndef _ASSERT_H
#define _ASSERT_H
#include <stdio.h>
#include <stdlib.h>
#define assert(e) ((e)?(void)0:(fprintf(stderr,"Assertion failed: %s (%s:%d)\n",#e,__FILE__,__LINE__),abort()))
#endif
