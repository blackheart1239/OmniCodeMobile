#ifndef _STDIO_H
#define _STDIO_H
#include <stddef.h>
#include <stdarg.h>
typedef struct __sFILE FILE;
extern FILE *stdin, *stdout, *stderr;
#define EOF (-1)
int printf(const char*,...); int fprintf(FILE*,const char*,...); int sprintf(char*,const char*,...);
int snprintf(char*,size_t,const char*,...); int vprintf(const char*,va_list); int vfprintf(FILE*,const char*,va_list);
int vsnprintf(char*,size_t,const char*,va_list);
int scanf(const char*,...); int sscanf(const char*,const char*,...); int fscanf(FILE*,const char*,...);
int puts(const char*); int putchar(int); int getchar(void); int fputs(const char*,FILE*); int fputc(int,FILE*);
char *fgets(char*,int,FILE*); int fgetc(FILE*); int fflush(FILE*);
FILE *fopen(const char*,const char*); int fclose(FILE*);
size_t fread(void*,size_t,size_t,FILE*); size_t fwrite(const void*,size_t,size_t,FILE*);
void perror(const char*);
#endif
