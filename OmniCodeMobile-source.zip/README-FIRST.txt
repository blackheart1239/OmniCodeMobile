OmniCode Mobile — experimental C compiler workflow files

UPLOAD THESE FILES TO THE ROOT OF YOUR EXISTING GitHub repository, preserving paths:
  .github/workflows/build-c-compiler.yml
  scripts/build-tcc-toolchain.sh

Then open GitHub > Actions > Build OmniCode offline C compiler > Run workflow.

IMPORTANT: This is an EXPERIMENTAL build attempt, not a verified compiler bundle.
A successful GitHub Actions run is not proof that TCC will execute on an Android phone.
Do not publish or install the resulting artifact until it has been tested on the target
ARM64 Android device. This ZIP does not include an APK and does not modify android.yml.
